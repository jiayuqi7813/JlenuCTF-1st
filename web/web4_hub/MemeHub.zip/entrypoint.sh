#!/bin/sh

python3 app.py
