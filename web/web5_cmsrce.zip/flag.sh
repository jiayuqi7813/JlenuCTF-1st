#!/usr/bin/env sh
mysql -e "create database ycc; use ycc;source /db.sql;" -uroot -proot

export FLAG=not_flag
FLAG=not_flag

rm -rf /db.sql
rm -rf /flag.sh
