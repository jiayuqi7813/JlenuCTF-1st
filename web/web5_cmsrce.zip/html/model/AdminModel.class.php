<?php
//管理员实体类
class AdminModel extends Model{
	private $username;
	private $password;
	//拦截器(__set)
	public function __set($_key, $_value) {
		$this->$_key = tool::setFormString($_value);
	}
	
	//拦截器(__get)
	public function __get($_key){
		return $this->$_key;
	}
	
	//验证管理员
	public function selectAdmin(){
		$_sql="SELECT 
					*
				FROM 
					my_admin 
				WHERE
					username='$this->username'
				AND
					password='$this->password'
				LIMIT 1";
		return parent::select($_sql);
	}
	//修改管理员密码
	public function editAdmin(){
		$_sql="UPDATE
					my_admin
				SET
					username='$this->username',
					password='$this->password'
				WHERE
					id=1
				LIMIT 1";
		return parent::update($_sql);
	}
	//设置登录次数,时间
	public function setLogin(){
		$_sql="UPDATE 
					my_admin
				SET
					count=count+1,
					login_time=NOW()
				WHERE
					username='$this->username'
				LIMIT 1";
		return parent::update($_sql);
	}
	
     //验证登录
	public function check_Admin(){
		$_sql="SELECT 
					*
				FROM 
					my_admin 
				WHERE
					username='$this->username'
				AND
					password='$this->password'
				LIMIT 1";
		return parent::select($_sql);
	}
}


?>