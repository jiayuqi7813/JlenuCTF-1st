<?php /* Smarty version 2.6.26, created on 2018-08-28 21:37:10
         compiled from admin/article/update.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'getcolor', 'admin/article/update.tpl', 22, false),)), $this); ?>
<!doctype html>
<html>
<head>
<meta charset="utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<title>修改文章</title>
<link rel="stylesheet" type="text/css" href="../view/admin/style/basic.css" />
<link rel="stylesheet" type="text/css" href="../view/admin/style/article.css" />
<script type="text/javascript" src="../public/xh/jquery/jquery-1.8.3.min.js"></script>
<script type="text/javascript" src="../public/xh/xheditor-1.2.2.min.js"></script>
<script type="text/javascript" src="../public/xh/zh-cn.js"></script>
<script type="text/javascript" src="../public/js/jquery.validate.js"></script>
<script type="text/javascript" src="../public/js/article.js"></script>
</head>
<body style="background:#EBF1F3;">
<div id="current">当前位置 &gt; <a href="?" target="_parent">后台首页</a>&gt; 修改文章</div>
<div id="article">
<form name="add" id="add" method="post" action="?a=article&m=update">
<input type="hidden" name="id" value="<?php echo $this->_tpl_vars['id']; ?>
" />
<input type="hidden" name="prev_url" value="<?php echo $this->_tpl_vars['prev_url']; ?>
" />
<dl>
	<dd><strong>文章标题 :</strong>　<input type="text" name="title" value="<?php echo $this->_tpl_vars['title']; ?>
" class="text"/>&nbsp;<?php echo getcolor(array('name' => 'color','value' => $this->_tpl_vars['color']), $this);?>
&nbsp;<span class="red">*</span></dd>
	<dd><strong>所属分类 :</strong>　<select name="cid"><option value="" selected="selected">--请选择一个分类--</option><?php echo $this->_tpl_vars['nav']; ?>
</select>&nbsp;<span class="red">*</span></dd>
	<dd><strong>自定义属性 :</strong>　<?php echo $this->_tpl_vars['attr']; ?>

	</dd>
	<dd><strong>TAG标签 :</strong>　<input type="text" name="tag" value="<?php echo $this->_tpl_vars['tag']; ?>
" class="text"/>&nbsp;<span class="red">*</span>&nbsp; <em class="gray">多个tag用","隔开,第一个tag用于显示内容页的相关内容</em></dd>
	<dd><strong>作者 :</strong>　<input type="text" name="author" class="text small" value="<?php echo $this->_tpl_vars['author']; ?>
"/></dd>
	<dd><strong>来源 :</strong>　<input type="text" id="source" name="source" class="text small" value="<?php echo $this->_tpl_vars['source']; ?>
"/>&nbsp;
	  <input type="button" class="button" onclick="source.value='本站'" value="本站" />&nbsp;
	  <input type="button" class="button" onclick="source.value='互联网'" value="互联网" />&nbsp;
	  <input type="button" class="button" onclick="source.value='未知'" value="未知" />&nbsp;
	</dd>
	<dd><strong>简介/摘要 :</strong>　<textarea name="info"><?php echo $this->_tpl_vars['info']; ?>
</textarea>&nbsp;<span class="red">*</span></dd>
	<dd><strong>内容 :</strong>　<textarea id="content" name="content" class="xh"><?php echo $this->_tpl_vars['content']; ?>
</textarea>&nbsp;<span class="red">*</span></dd>
	<dd class="noline"><input type="submit" name="send" value="提交修改" class="submit"/></dd>
</dl>
</form>
</div>
</body>
</html>