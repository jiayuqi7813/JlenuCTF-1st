<?php /* Smarty version 2.6.26, created on 2018-08-19 18:08:23
         compiled from admin/dan/show.tpl */ ?>
<!doctype html>
<html>
<head>
<meta charset="utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<title>单页管理</title>
<link rel="stylesheet" type="text/css" href="../view/admin/style/basic.css" />
<link rel="stylesheet" type="text/css" href="../view/admin/style/dan.css" />
<script type="text/javascript" src="../public/js/jquery-1.8.1.min.js"></script>
<script type="text/javascript" src="../public/layer/layer.js"></script>
<script type="text/javascript" src="../public/js/nav.js"></script>
</head>
<body style="background:#EBF1F3;">
<div id="current">当前位置 &gt; <a href="?" target="_parent">后台首页</a>&gt; 单页管理 [ <a href="?a=dan&m=add" target="in">添加单页</a> ]</div>
<div id="dan">
<form method="post" action="?a=dan&m=sort">
<table class="dan">
<tr>
	<th>排 序</th>
	<th>ID</th>
	<th style="width:170px;">单页名称</th>
	<th>文件名</th>
	<th>菜单显示</th>
	<th>已生成静态</th>
	<th>时间</th>
	<th width="100px;">管 理</th>
</tr>
<?php $_from = $this->_tpl_vars['AllDan']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['key'] => $this->_tpl_vars['value']):
?>
<tr>
	<td class="left"><input type="text" name="sort[<?php echo $this->_tpl_vars['value']->id; ?>
]" class="sort" value="<?php echo $this->_tpl_vars['value']->sort; ?>
"/></td>
	<td><?php echo $this->_tpl_vars['value']->id; ?>
</td>
	<td><?php echo $this->_tpl_vars['value']->dan_name; ?>
</td>
	<td><?php echo $this->_tpl_vars['value']->filename; ?>
</td>
	<td><?php if ($this->_tpl_vars['value']->isshow == 1): ?><a href="?a=dan&m=isshow&id=<?php echo $this->_tpl_vars['value']->id; ?>
&show=0"><img src="../view/admin/images/yes.png" /></a><?php else: ?><a href="?a=dan&m=isshow&id=<?php echo $this->_tpl_vars['value']->id; ?>
&show=1"><img src="../view/admin/images/no.png" /></a><?php endif; ?></td>
	<td><?php if ($this->_tpl_vars['value']->ishtml == 0): ?><a href="?a=html&m=dan&id=<?php echo $this->_tpl_vars['value']->id; ?>
" title="点击生成静态"><img src="../view/admin/images/no.png" /></a><?php else: ?><a href="#" title="已生成静态"><img src="../view/admin/images/yes.png" /></a><?php endif; ?><?php if ($this->_tpl_vars['value']->ishtml == 1): ?>&nbsp;&nbsp;<a href="?a=html&m=dan&id=<?php echo $this->_tpl_vars['value']->id; ?>
" title="重新生成"><img src="../view/admin/images/agin.png" /></a><?php endif; ?></td>
	<td><?php echo $this->_tpl_vars['value']->time; ?>
</td>
	<td><a href="?a=dan&m=update&id=<?php echo $this->_tpl_vars['value']->id; ?>
" title="修改"><img src="../view/admin/images/edit.png" alt="修改"/></a>　<a href="?a=dan&m=delete&id=<?php echo $this->_tpl_vars['value']->id; ?>
" title="删除" onclick="return confirm('确定要删除 <?php echo $this->_tpl_vars['value']->filename; ?>
 吗？删除后不可恢复！')?true : false"><img src="../view/admin/images/del.png" alt="删除"/></a></td>
</tr>
<?php endforeach; else: ?>
<tr>
	<td colspan="7" ><p class="error">还没有单页!</p></td>
</tr>
<?php endif; unset($_from); ?>
<tr class="nobg">
	<td colspan="8" class="noline"><input type="submit" name="send" value="更新排序" class="submit"/></td>
</tr>
</table>
</form>
<table class="sm">
<tr><th>设置帮助</th></tr>
<tr><td>
<ul>
<li>3、“排序”数字越小排名越靠前。</li>
<li>1、“菜单显示”点击下面的状态按钮进行切换，YES为显示、NO为不显示。</li>
<li>2、“已生成静态”点击下面按钮进行单页静态生成，静态文件生成后在根目录。</li>
<li>2、修改单页后会删除原有文件，需要重新生成。</li>
</ul>
</td></tr>
</table>
</div>
</body>
</html>