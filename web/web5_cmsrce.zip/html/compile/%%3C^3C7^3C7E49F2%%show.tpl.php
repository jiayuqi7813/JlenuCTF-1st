<?php /* Smarty version 2.6.26, created on 2018-08-18 22:31:31
         compiled from admin/link/show.tpl */ ?>
<!doctype html>
<html>
<head>
<meta charset="utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<title>链接列表</title>
<link rel="stylesheet" type="text/css" href="../view/admin/style/basic.css" />
<link rel="stylesheet" type="text/css" href="../view/admin/style/link.css" />
<script type="text/javascript" src="../public/js/link.js"></script>
</head>
<body style="background:#EBF1F3;">
<div id="current">当前位置 &gt; <a href="?" target="_parent">后台首页</a>&gt; 链接列表&nbsp;[<a href="?a=link&m=add">添加链接</a>]</div>
<div id="link">
<form method="post" action="?a=link&m=sort">
<table class="lk">
<tr>
	<th class="left">排 序</th>
	<th>ID</th>
	<th>链接名称</th>
	<th>URL</th>
	<th>时间</th>
	<th>管 理</th>
</tr>
<?php $_from = $this->_tpl_vars['AllLink']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['key'] => $this->_tpl_vars['value']):
?>
<tr>
	<td class="left"><input type="text" name="sort[<?php echo $this->_tpl_vars['value']->id; ?>
]" class="sort" value="<?php echo $this->_tpl_vars['value']->sort; ?>
"/></td>
	<td><?php echo $this->_tpl_vars['value']->id; ?>
</td>
	<td><?php echo $this->_tpl_vars['value']->linkname; ?>
</td>
	<td><a href="<?php echo $this->_tpl_vars['value']->linkurl; ?>
" target="_blank"><?php echo $this->_tpl_vars['value']->linkurl; ?>
</a></td>
	<td><?php echo $this->_tpl_vars['value']->time; ?>
</td>
	<td><a href="?a=link&m=update&id=<?php echo $this->_tpl_vars['value']->id; ?>
" title="修改"><img src="../view/admin/images/edit.png" alt="修改"/></a>　<a href="?a=link&m=delete&id=<?php echo $this->_tpl_vars['value']->id; ?>
" title="删除" onclick="return confirm('真的要删除这个链接吗?删除后不可恢复!!!') ? true : false"><img src="../view/admin/images/del.png" alt="删除"/></a></td>
</tr>
<?php endforeach; else: ?>
<tr>
	<td colspan="6" class="center"><p class="error">没有任何链接!</p></td>
</tr>
<?php endif; unset($_from); ?>
<tr class="nobg">
	<td colspan="2" class="noline"><input type="submit" name="send" value="更新排序" class="submit"/></td><td colspan="4" class="noline"><div id="page"><?php echo $this->_tpl_vars['page']; ?>
</div></td>
</tr>
</table>
</form>
<table class="sm">
<tr><th>设置帮助</th></tr>
<tr><td>
<ul>
<li>“排序”数字越小排名越靠前。</li>
</ul>
</td></tr>
</table>
</div>
</body>
</html>