<?php /* Smarty version 2.6.26, created on 2018-08-12 23:08:48
         compiled from admin/public/picshow.tpl */ ?>
<!doctype html>
<html>
<head>
<meta charset="utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<title>图片管理</title>
<link rel="stylesheet" type="text/css" href="../view/admin/style/basic.css" />
<link rel="stylesheet" type="text/css" href="../view/admin/style/pic.css" />
<script type="text/javascript" src="../public/js/jquery-1.8.1.min.js"></script>
<script type="text/javascript" src="../public/js/pic.js"></script>
</head>
<body style="background:#EBF1F3;">
<div id="current">当前位置 &gt; <a href="?" target="_parent">后台首页</a>&gt; 图片管理</div>
<div id="pic">
<form method="post" action="?a=pic&m=delall">
<dl id="allcheckbox">
<?php $_from = $this->_tpl_vars['picArr']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['key'] => $this->_tpl_vars['value']):
?>
	<dd><img src="../uploads/<?php echo $this->_tpl_vars['value']; ?>
"/><input type="checkbox" name="pid[<?php echo $this->_tpl_vars['key']; ?>
]" value="<?php echo $this->_tpl_vars['value']; ?>
" /></dd>
<?php endforeach; else: ?>
<dd class="error">没有任何图片!<dd>
<?php endif; unset($_from); ?>
</dl>
<table>
<tr>
	<td><input type="checkbox" onclick="CheckAll(this.form);" name="chkall" /> 全选 <input type="submit" name="send" value="删除选中图片" class="button" onclick="return confirm('确定要删除选定的图片吗？删除后不可恢复！')?true : false" />&nbsp;共&nbsp;<?php echo $this->_tpl_vars['picNum']; ?>
&nbsp;张图片</td>
	<td></td>
</tr>
</table>
</form>
</div>
</body>
</html>