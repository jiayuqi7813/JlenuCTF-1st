<?php /* Smarty version 2.6.26, created on 2018-08-14 22:35:41
         compiled from admin/nav/update.tpl */ ?>
<!doctype html>
<html>
<head>
<meta charset="utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<title>修改分类</title>
<link rel="stylesheet" type="text/css" href="../view/admin/style/basic.css" />
<link rel="stylesheet" type="text/css" href="../view/admin/style/nav.css" />
<script type="text/javascript" src="../public/js/jquery-1.8.1.min.js"></script>
<script type="text/javascript" src="../public/js/jquery.validate.js"></script>
<script type="text/javascript" src="../public/js/nav.js"></script>
</head>
<body style="background:#EBF1F3;">
<div id="current">当前位置 &gt; <a href="?" target="_parent">后台首页</a>&gt; <?php if ($this->_tpl_vars['OneNav'][0]->nid == 0): ?>修改主分类<?php else: ?>修改子分类<?php endif; ?></div>
<div id="nav">
<form name="add" id="add" method="post" action="?a=nav&m=update">
<?php if ($this->_tpl_vars['OneNav']): ?>
<input type="hidden" name="id" value="<?php echo $this->_tpl_vars['OneNav'][0]->id; ?>
" />
<?php endif; ?>
<?php if ($this->_tpl_vars['OneNav'][0]->nid != 0): ?>
<input type="hidden" name="nid" value="<?php echo $this->_tpl_vars['OneNav'][0]->id; ?>
" />
<?php endif; ?>
<dl>
<?php if ($this->_tpl_vars['OneNav'][0]->nid != 0): ?><dd><strong>主分类名称 :</strong>　<?php echo $this->_tpl_vars['ParentNav'][0]->nav_name; ?>
</dd><?php endif; ?>
<dd><strong>分类名称 :</strong>　<input type="text" name="nav_name" class="text" value="<?php echo $this->_tpl_vars['OneNav'][0]->nav_name; ?>
"/>&nbsp;<span class="red">*</span>&nbsp;<em class="gray">中文名称(必填)</em></dd>
<?php if ($this->_tpl_vars['OneNav'][0]->nid == 0): ?>
<dd><strong>英文别名 :</strong>　<input type="text" name="nav_ename" class="text" value="<?php echo $this->_tpl_vars['OneNav'][0]->nav_ename; ?>
"/>&nbsp;<span class="red">*</span>&nbsp;<em class="gray">英文名称(必填)</em></dd>
<?php endif; ?>
<dd><strong>分类标题 :</strong>　<input type="text" name="title" class="text" value="<?php echo $this->_tpl_vars['OneNav'][0]->title; ?>
"/>&nbsp;<span class="red">*</span></dd>
<dd><strong>关 键 词 :</strong>　<input type="text" name="keyword" class="text" value="<?php echo $this->_tpl_vars['OneNav'][0]->keyword; ?>
"/>&nbsp;<span class="red">*</span></dd>
<dd><strong>描 述 :</strong>　<textarea name="info"><?php echo $this->_tpl_vars['OneNav'][0]->info; ?>
</textarea>&nbsp;<span class="red">*</span></dd>
<dd><input type="submit" name="send" value="修改分类" class="submit"/></dd>
</dl>
</form>
</div>
</body>
</html>