<?php /* Smarty version 2.6.26, created on 2018-08-18 22:25:47
         compiled from admin/public/online.tpl */ ?>
<!doctype html>
<html>
<head>
<meta charset="utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<title>后台管理首页</title>
<link rel="stylesheet" type="text/css" href="../view/admin/style/basic.css" />
<link rel="stylesheet" type="text/css" href="../view/admin/style/online.css" />
<script type="text/javascript" src="../public/js/online.js"></script>
</head>
<body style="background:#EBF1F3;">
<div id="current"></p>当前位置 &gt; <a href="?" target="_parent">后台首页</a>&gt; 访客信息</div>
<div id="online">
<form method="post" action="?a=online&m=delall">
<table class="onl">
<tr>
	<th></th>
	<th>编号</th>
	<th>IP</th>
	<th>访问时间</th>
	<th>来路(URL)</th>
	<th>操作系统</th>
	<th>浏览器</th>
	<th>管 理</th>
</tr>
<?php $_from = $this->_tpl_vars['AllOnline']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['key'] => $this->_tpl_vars['value']):
?>
<tr>
	<td><input type="checkbox" value="<?php echo $this->_tpl_vars['value']->id; ?>
" name="showid[]"/></td>
	<td><?php echo $this->_tpl_vars['value']->id; ?>
</td>
	<td class="two"><a href="http://www.ip138.com/ips138.asp?ip=<?php echo $this->_tpl_vars['value']->ip; ?>
" target="_blank"><?php echo $this->_tpl_vars['value']->ip; ?>
</a><br />( <?php echo $this->_tpl_vars['value']->_ip; ?>
 )</td>
	<td><?php echo $this->_tpl_vars['value']->time; ?>
</td>
	<td><?php echo $this->_tpl_vars['value']->lailu; ?>
</td>
	<td><?php echo $this->_tpl_vars['value']->_os; ?>
</td>
	<td><?php echo $this->_tpl_vars['value']->_browser; ?>
</td>
	<td><a href="?a=online&m=delete&id=<?php echo $this->_tpl_vars['value']->id; ?>
" title="删除" ><img src="../view/admin/images/del.png" alt="删除"/></a></td>
</tr>
<?php endforeach; else: ?>
<tr>
	<td colspan="8" class="center"><p class="error">没有访客记录!</p></td>
</tr>
<?php endif; unset($_from); ?>
<tr class="nobg">
	<td colspan="2" class="noline left"><input type="checkbox" onclick="CheckAll(this.form);" name="chkall" /> 全选 <input type="submit" name="send" value="批量删除" class="button" /></td><td colspan="7" class="noline"><div id="page"><?php echo $this->_tpl_vars['page']; ?>
</div> </td>
</tr>
</table>
</form>
<table class="sm">
<tr><th>设置帮助</th></tr>
<tr><td>
<ul>
<li>为防止数据库过大，访客记录只保留一个月内的访问信息。</li>
</ul>
</td></tr>
</table>
</div>
</body>
</html>