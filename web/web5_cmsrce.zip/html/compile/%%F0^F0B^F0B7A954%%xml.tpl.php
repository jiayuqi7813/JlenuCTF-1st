<?php /* Smarty version 2.6.26, created on 2018-08-15 22:43:32
         compiled from admin/public/xml.tpl */ ?>
<!doctype html>
<html>
<head>
<meta charset="utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<title>生成网站地图</title>
<link rel="stylesheet" type="text/css" href="../view/admin/style/basic.css" />
<link rel="stylesheet" type="text/css" href="../view/admin/style/cache.css" />
</head>
<body style="background:#EBF1F3;">
<div id="current">当前位置 &gt; <a href="?" target="_parent">后台首页</a>&gt; 清理编译缓存</div>
<div id="cache">
<form method="post" action="?a=xml">
<dl>
<dt>提示:</dt>
<dd>网站地图为XML格式,生成后在网站根目录。</dd>
<dd>预览地址 : <a href="<?php echo $this->_tpl_vars['sys'][0]->url; ?>
/sitemap.xml" target="_blank"><?php echo $this->_tpl_vars['sys'][0]->url; ?>
/sitemap.xml</a></dd>
<?php if ($_GET['index']): ?>
<dd><span class="state">网站地图生成完毕!!</span></dd>
<?php endif; ?>

<dd class="no"><input type="submit" name="send" value="点击这里生成网站地图" class="submit" /></dd>
</dl>
</form>
</div>
</body>
</html>