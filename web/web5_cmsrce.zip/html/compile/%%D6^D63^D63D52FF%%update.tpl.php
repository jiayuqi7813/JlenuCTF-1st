<?php /* Smarty version 2.6.26, created on 2018-08-18 22:26:36
         compiled from admin/public/update.tpl */ ?>
<!doctype html>
<html>
<head>
<meta charset="utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<title>后台管理首页</title>
<link rel="stylesheet" type="text/css" href="../view/admin/style/basic.css" />
<link rel="stylesheet" type="text/css" href="../view/admin/style/admin.css" />
<script type="text/javascript" src="../public/js/jquery-1.8.1.min.js"></script>
<script type="text/javascript" src="../public/js/jquery.validate.js"></script>
<script type="text/javascript" src="../public/js/pass.js"></script>
</head>
<body style="background:#EBF1F3;">
<div id="current">当前位置 &gt; <a href="?" target="_parent">后台首页</a>&gt; 修改密码</div>
<div id="password">
<form id="pass" method="post" action="?a=admin&m=update">
<dl>
<dd><strong>用  户  名:　</strong>　<input type="text" name="username" class="text" value="<?php echo $this->_tpl_vars['admin']['username']; ?>
"/>&nbsp;<span class="red">*</span></dd>
<dd><strong>新  密  码:　</strong>　<input type="password" name="password" class="text" id="pass1"/>&nbsp;<span class="red">*</span></dd>
<dd><strong>重复密码:　</strong>　<input type="password" name="notpassword" class="text"/>&nbsp;<span class="red">*</span></dd>
<dd><input type="submit" name="send" value="修改密码" class="submit"></dd>
</dl>
</form>
</div>
</body>
</html>