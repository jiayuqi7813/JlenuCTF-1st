<?php /* Smarty version 2.6.26, created on 2018-08-13 21:42:46
         compiled from admin/article/show.tpl */ ?>
<!doctype html>
<html>
<head>
<meta charset="utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<title>文章列表</title>
<link rel="stylesheet" type="text/css" href="../view/admin/style/basic.css" />
<link rel="stylesheet" type="text/css" href="../view/admin/style/article.css" />
<script type="text/javascript" src="../public/js/jquery-1.8.1.min.js"></script>
<script type="text/javascript" src="../public/js/article.js"></script>
</head>
<body style="background:#EBF1F3;">
<div id="current">当前位置 &gt; <a href="?" target="_parent">后台首页</a>&gt; 文章列表</div>
<div id="article" >
<form method="get" action="?">
<table width="100%" align="center" class="search">
<tr>
	<td><input type="hidden" name="a" value="article"/><input type="text" name="keywords" class="text"/>&nbsp;<input type="submit" name="search" value="搜索" class="button"/><input type="button" value="返回列表" onclick="javascrip:location.href='?a=article'" class="button"/></td>
</tr>
</table>
</form>
<form method="post" action="?a=article&m=delall">
<table class="art">
<tr>
	<th></th>
	<th>ID</th>
	<th>分类</th>
	<th>标题</th>
	<th>作者</th>
	<th>时间</th>
	<th>修改时间</th>
	<th>已生成静态</th>
	<th>管 理</th>
</tr>
<?php $_from = $this->_tpl_vars['artList']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['key'] => $this->_tpl_vars['value']):
?>
<tr>
	<td><input type="checkbox" value="<?php echo $this->_tpl_vars['value']->id; ?>
" name="showid[]"/></td>
	<td><?php echo $this->_tpl_vars['value']->id; ?>
</td>
	<td><a href="?a=article&par_id=<?php echo $this->_tpl_vars['value']->par_id; ?>
"><?php echo $this->_tpl_vars['value']->par_name; ?>
</a></td>
	<td style="text-align:left;"><a href="../<?php echo $this->_tpl_vars['value']->html; ?>
" target="_blank"  style="color:<?php echo $this->_tpl_vars['value']->color; ?>
;<?php if ($this->_tpl_vars['value']->b): ?>font-weight:bold;<?php endif; ?>"><?php echo $this->_tpl_vars['value']->title; ?>
</a>
	<?php if ($this->_tpl_vars['value']->thumb): ?><span class="thumb">图片</span><?php endif; ?>	
	<?php if ($this->_tpl_vars['value']->commend): ?><span class="commend">推荐</span><?php endif; ?>
	<?php if ($this->_tpl_vars['value']->top): ?><span class="top">置顶</span><?php endif; ?>
	</td>
	<td><?php echo $this->_tpl_vars['value']->author; ?>
</td>
	<td><?php echo $this->_tpl_vars['value']->time; ?>
</td>
	<td><?php echo $this->_tpl_vars['value']->updatetime; ?>
</td>
	<td><?php if ($this->_tpl_vars['value']->ishtml == 0): ?><a href="?a=html&m=art&id=<?php echo $this->_tpl_vars['value']->id; ?>
" title="点击生成静态"><img src="../view/admin/images/no.png" /></a><?php else: ?><a href="#" title="已生成静态"><img src="../view/admin/images/yes.png" /></a><?php endif; ?><?php if ($this->_tpl_vars['value']->ishtml == 1): ?>&nbsp;&nbsp;<a href="?a=html&m=art&id=<?php echo $this->_tpl_vars['value']->id; ?>
" title="重新生成"><img src="../view/admin/images/agin.png" /></a><?php endif; ?></td>
	<td><a href="?a=article&m=update&id=<?php echo $this->_tpl_vars['value']->id; ?>
" title="修改"><img src="../view/admin/images/edit.png" alt="修改"/></a>　<a href="?a=article&m=delete&id=<?php echo $this->_tpl_vars['value']->id; ?>
" title="删除" onclick="return confirm('你真的要删除这篇文章吗?删除后不可恢复!!!') ? true : false"><img src="../view/admin/images/del.png" alt="删除"/></a></td>
</tr>
<?php endforeach; else: ?>
<tr>
	<td colspan="8" class="center"><p class="error">没有任何文章!</p></td>
</tr>
<?php endif; unset($_from); ?>
<tr class="nobg">
	<td colspan="2" class="noline left"><input type="checkbox" onclick="CheckAll(this.form);" name="chkall" /> 全选 <input type="submit" name="send" value="批量删除" class="button" onclick="return confirm('确定要删除选定的内容吗？删除后不可恢复！')?true : false" /></td><td colspan="7" class="noline"><div id="page"><?php echo $this->_tpl_vars['page']; ?>
</div> </td>
</tr>
</table>
</form>
<table class="sm">
<tr><th>设置帮助</th></tr>
<tr><td>
<ul>
<li>1、点击分类名称可以查看属于该分类下所有文章。</li>
<li>2、刚添加的文章可以点击“已生成静态”下的状态图标单独生成静态。</li>
<li>2、修改文章后，系统会删除原静态文件，须重新生成。</li>
</ul>
</td></tr>
</table>
</div>
</body>
</html>