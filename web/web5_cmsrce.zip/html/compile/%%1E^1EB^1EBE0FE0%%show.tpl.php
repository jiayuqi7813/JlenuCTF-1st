<?php /* Smarty version 2.6.26, created on 2018-08-18 22:29:14
         compiled from admin/nav/show.tpl */ ?>
<!doctype html>
<html>
<head>
<meta charset="utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<title>分类管理</title>
<link rel="stylesheet" type="text/css" href="../view/admin/style/basic.css" />
<link rel="stylesheet" type="text/css" href="../view/admin/style/nav.css" />
<script type="text/javascript" src="../public/js/jquery-1.8.1.min.js"></script>
<script type="text/javascript" src="../public/layer/layer.js"></script>
<script type="text/javascript" src="../public/js/nav.js"></script>
</head>
<body style="background:#EBF1F3;">
<div id="current">当前位置 &gt; <a href="?" target="_parent">后台首页</a>&gt; 分类管理</div>
<div id="nav">
<form method="post" action="?a=nav&m=sort">
<table class="fl">
<tr>
	<th>排 序</th>
	<th>ID</th><th style="width:170px;">分类名称</th>
	<th>英文别名</th>
	<th>内容数</th>
	<th>清空目录</th>
	<th width="100px;">管 理</th>
</tr>
<?php $_from = $this->_tpl_vars['AllNav']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['key'] => $this->_tpl_vars['value']):
?>
<tr>
	<td class="left"><input type="text" name="sort[<?php echo $this->_tpl_vars['value']->id; ?>
]" class="sort" value="<?php echo $this->_tpl_vars['value']->sort; ?>
"/></td>
	<td><?php echo $this->_tpl_vars['value']->id; ?>
</td>
	<td><?php echo $this->_tpl_vars['value']->nav_name; ?>
</td>
	<td><?php echo $this->_tpl_vars['value']->nav_ename; ?>
</td>
	<td><?php echo $this->_tpl_vars['value']->arts; ?>
</td>
	<td>[<a href="?a=nav&m=clean&navname=<?php echo $this->_tpl_vars['value']->nav_ename; ?>
" title="清理该分类目录下的所有静态文件">清理</a>]</td>
	<td><a href="?a=nav&m=update&id=<?php echo $this->_tpl_vars['value']->id; ?>
" title="修改"><img src="../view/admin/images/edit.png" alt="修改"/></a>　<a href="?a=nav&m=delete&id=<?php echo $this->_tpl_vars['value']->id; ?>
" title="删除" onclick="return confirm('确定要删除这个分类吗?删除后不可恢复！')?true : false"><img src="../view/admin/images/del.png" alt="删除"/></a></td>
</tr>
<?php endforeach; else: ?>
<tr>
	<td colspan="7" ><p class="error">没有任何分类!</p></td>
</tr>
<?php endif; unset($_from); ?>
<tr class="nobg">
	<td colspan="8" class="noline"><input type="submit" name="send" value="更新排序" class="submit"/></td>
</tr>
</table>
</form>
<table class="sm">
<tr><th>设置帮助</th></tr>
<tr><td>
<ul>
<li>1、“内容数”显示该分类下的文章数量。</li>
<li>2、“清空目录”会删除该分类目录下已生成的所有静态文件。</li>
<li>3、“排序”数字越小排名越靠前。</li>
</ul>
</td></tr>
</table>
</div>
</body>
</html>