<?php /* Smarty version 2.6.26, created on 2018-08-19 18:45:47
         compiled from admin/dan/update.tpl */ ?>
<!doctype html>
<html>
<head>
<meta charset="utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<title>修改单页</title>
<link rel="stylesheet" type="text/css" href="../view/admin/style/basic.css" />
<link rel="stylesheet" type="text/css" href="../view/admin/style/dan.css" />
<script type="text/javascript" src="../public/xh/jquery/jquery-1.8.3.min.js"></script>
<script type="text/javascript" src="../public/xh/xheditor-1.2.2.min.js"></script>
<script type="text/javascript" src="../public/xh/zh-cn.js"></script>
<script type="text/javascript" src="../public/js/jquery.validate.js"></script>
<script type="text/javascript" src="../public/js/dan.js"></script>
</head>
<body style="background:#EBF1F3;">
<div id="current">当前位置 &gt; <a href="?" target="_parent">后台首页</a>&gt; 修改单页</div>
<div id="dan">
<form name="add" id="add" method="post" action="?a=dan&m=update">
<input type="hidden" name="id" value="<?php echo $this->_tpl_vars['id']; ?>
" />
<dl>
<dd><strong>单页名称 :</strong>　<input type="text" name="dan_name" value="<?php echo $this->_tpl_vars['dan_name']; ?>
" class="text"/>&nbsp;<span class="red">*</span></dd>
<dd><strong>文 件 名 :</strong>　<input type="text" name="filename" value="<?php echo $this->_tpl_vars['filename']; ?>
" disabled class="text edit"/>&nbsp;<span class="red">*</span>&nbsp; <em class="gray">文件名不可修改</em></dd>
<dd><strong>菜单显示 :</strong>　<input type="checkbox" name="isshow" <?php if ($this->_tpl_vars['isshow'] == 1): ?> checked="checked"<?php endif; ?> value="1" class="box"/></dd>
<dd><strong>单页标题 :</strong>　<input type="text" name="title" value="<?php echo $this->_tpl_vars['title']; ?>
" class="text"/>&nbsp;<span class="red">*</span></dd>
<dd><strong>关 键 词 :</strong>　<input type="text" name="keywords" value="<?php echo $this->_tpl_vars['keywords']; ?>
" class="text"/>&nbsp;<span class="red">*</span></dd>
<dd><strong>描 述 :</strong>　<textarea name="desc"><?php echo $this->_tpl_vars['desc']; ?>
</textarea>&nbsp;<span class="red">*</span></dd>
<dd><strong>内容 :</strong>　<textarea id="content" name="content" class="xh"><?php echo $this->_tpl_vars['content']; ?>
</textarea>&nbsp;<span class="red">*</span></dd>
<dd><input type="submit" name="send" value="修改单页" class="submit"/></dd>
</dl>
</form>
<table class="sm">
<tr><th>设置帮助</th></tr>
<tr><td>
<ul>
<li>1、单页名称：如：产品介绍，用于显示在前台菜单中。</li>
<li>2、文件名：不可以是中文，扩展中必须是：html 如：abc.html。</li>
<li>3、菜单显示：是否显示在前台菜单中）。</li>
</ul>
</td></tr>
</table>
</div>
</body>
</html>