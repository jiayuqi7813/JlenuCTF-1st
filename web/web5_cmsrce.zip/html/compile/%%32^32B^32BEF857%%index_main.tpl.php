<?php /* Smarty version 2.6.26, created on 2018-08-13 22:19:17
         compiled from admin/public/index_main.tpl */ ?>
<!doctype html>
<html>
<head>
<meta charset="utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<title>首页内容</title>
<link rel="stylesheet" type="text/css" href="../view/admin/style/basic.css" />
<link rel="stylesheet" type="text/css" href="../view/admin/style/index_main.css" />
<script type="text/javascript" src="../public/xh/jquery/jquery-1.8.3.min.js"></script>
<script type="text/javascript" src="../public/xh/xheditor-1.2.2.min.js"></script>
<script type="text/javascript" src="../public/xh/zh-cn.js"></script>
<script type="text/javascript" src="../public/js/jquery.validate.js"></script>
<script type="text/javascript" src="../public/js/index_main.js"></script>
</head>
<body style="background:#EBF1F3;">
<div id="current">当前位置 &gt; <a href="?" target="_parent">后台首页</a>&gt; 首页内容</div>
<div id="index_main">
<form name="add" id="index_main" method="post" action="?a=system&m=main">
<dl>
<dd><textarea id="content" name="content" class="xh"><?php echo $this->_tpl_vars['content']; ?>
</textarea>&nbsp;<span class="red">*</span></dd>
<dd class="noline"><input type="submit" name="send" value="保存内容" class="submit"/></dd>
</dl>
</form>
<table class="sm">
<tr><th>设置帮助</th></tr>
<tr><td>
<ul>
<li>网站前台首页的主体内容。</li>
</ul>
</td></tr>
</table>
</div>
</body>
</html>