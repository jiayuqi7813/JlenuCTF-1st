/*
Navicat MySQL Data Transfer

Source Server         : 111
Source Server Version : 50524
Source Host           : localhost:3306
Source Database       : yccms

Target Server Type    : MYSQL
Target Server Version : 50524
File Encoding         : 65001

Date: 2018-08-29 21:55:34
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for my_admin
-- ----------------------------
DROP TABLE IF EXISTS `my_admin`;
CREATE TABLE `my_admin` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '//id',
  `username` varchar(20) NOT NULL COMMENT '//用户名',
  `password` char(40) NOT NULL COMMENT '//密码',
  `count` mediumint(8) unsigned NOT NULL COMMENT '//登录次数',
  `login_time` datetime DEFAULT NULL COMMENT '//登录时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of my_admin
-- ----------------------------
INSERT INTO `my_admin` VALUES ('1', 'admin', 'd033e22ae348aeb5660fc2140aec35850c4da997', '11', '2018-08-29 21:28:26');

-- ----------------------------
-- Table structure for my_article
-- ----------------------------
DROP TABLE IF EXISTS `my_article`;
CREATE TABLE `my_article` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '//ID',
  `title` varchar(200) NOT NULL COMMENT '//标题',
  `color` varchar(20) DEFAULT NULL COMMENT '//标题颜色',
  `cid` smallint(5) NOT NULL DEFAULT '0' COMMENT '//所属分类',
  `attr` varchar(100) DEFAULT NULL COMMENT '//自定义属性',
  `tag` varchar(200) DEFAULT NULL COMMENT '//TAG标签',
  `thumb` varchar(200) DEFAULT NULL COMMENT '//缩略图',
  `html` varchar(100) DEFAULT NULL COMMENT '//生成的静态htmlURL',
  `ishtml` tinyint(1) unsigned DEFAULT '0' COMMENT '//是否生成静态',
  `author` varchar(100) DEFAULT NULL COMMENT '//作者',
  `source` varchar(100) DEFAULT NULL COMMENT '//来源',
  `info` varchar(250) DEFAULT NULL COMMENT '//摘要',
  `content` text NOT NULL,
  `time` datetime NOT NULL COMMENT '//添加时间',
  `updatetime` datetime DEFAULT NULL COMMENT '//更新时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2451 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of my_article
-- ----------------------------
INSERT INTO `my_article` VALUES ('2446', '测试标题', '#000000', '85', '无', '11', '', 'ceshi1/2446.html', '1', 'Admin', '本站', '测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容', '<p>测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容。</p><p>测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容。</p><p>测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容。</p><p>测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容。<br /></p>', '2018-08-29 21:20:35', '2018-08-29 21:20:35');
INSERT INTO `my_article` VALUES ('2447', '测试标题1', '#FF0000', '85', '加粗', '11', '', 'ceshi1/2447.html', '1', 'Admin', '本站', '11', '<p>测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容。</p><p>测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容</p><p>测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容</p><p>测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容</p><p>测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容。。<br /></p>', '2018-08-29 21:21:12', '2018-08-29 21:21:12');
INSERT INTO `my_article` VALUES ('2448', '测试标题3', '#000000', '86', '无', '11', '', 'ceshi2/2448.html', '1', 'Admin', '本站', '22222', '<p>测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容。</p><p>测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容</p><p>测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容</p><p><br /></p>', '2018-08-29 21:21:43', '2018-08-29 21:21:43');
INSERT INTO `my_article` VALUES ('2449', '测试标题4', '#0000FF', '85', '无', '11', '', 'ceshi1/2449.html', '1', 'Admin', '本站', '222', '<p>测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容。</p><p>测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容。</p><p>测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容。</p>', '2018-08-29 21:22:15', '2018-08-29 21:22:15');
INSERT INTO `my_article` VALUES ('2450', '测试标题5', '#000000', '86', '无', '11', '', 'ceshi2/2450.html', '1', 'Admin', '本站', 'www11', '<p>测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容。</p><p>测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容。<br /></p>', '2018-08-29 21:22:39', '2018-08-29 21:22:39');

-- ----------------------------
-- Table structure for my_dan
-- ----------------------------
DROP TABLE IF EXISTS `my_dan`;
CREATE TABLE `my_dan` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT '//ID',
  `title` varchar(200) NOT NULL COMMENT '//标题',
  `dan_name` varchar(200) NOT NULL COMMENT '//单页名称',
  `isshow` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '//是否显示在首页',
  `ishtml` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '//是否静态',
  `filename` varchar(100) NOT NULL COMMENT '//文件名',
  `keywords` varchar(100) NOT NULL COMMENT '//关键词',
  `description` varchar(200) NOT NULL COMMENT '//描述',
  `content` text NOT NULL COMMENT '//主体',
  `sort` smallint(5) NOT NULL COMMENT '//排序',
  `time` datetime NOT NULL COMMENT '//添加时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of my_dan
-- ----------------------------

-- ----------------------------
-- Table structure for my_link
-- ----------------------------
DROP TABLE IF EXISTS `my_link`;
CREATE TABLE `my_link` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `linkname` varchar(20) NOT NULL COMMENT '//链接名称',
  `linkurl` varchar(200) NOT NULL COMMENT '//链接地址',
  `sort` smallint(5) unsigned DEFAULT NULL COMMENT '//排序',
  `time` datetime DEFAULT NULL COMMENT '//添加时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of my_link
-- ----------------------------
INSERT INTO `my_link` VALUES ('6', '百度', 'http://www.baidu.com', '6', '2018-08-12 21:39:01');
INSERT INTO `my_link` VALUES ('8', 'YCCMS', 'http://www.yccms.net/', '8', '2018-08-29 21:50:11');

-- ----------------------------
-- Table structure for my_nav
-- ----------------------------
DROP TABLE IF EXISTS `my_nav`;
CREATE TABLE `my_nav` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT '//id',
  `nav_name` varchar(20) NOT NULL COMMENT '//中文名字',
  `nav_ename` varchar(20) DEFAULT NULL,
  `title` varchar(200) DEFAULT NULL COMMENT '//分类标题',
  `keyword` varchar(100) NOT NULL COMMENT '//关键词',
  `info` varchar(200) DEFAULT NULL COMMENT '//描述',
  `sort` smallint(5) unsigned NOT NULL COMMENT '//排序',
  `time` datetime DEFAULT NULL COMMENT '//添加时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=87 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of my_nav
-- ----------------------------
INSERT INTO `my_nav` VALUES ('85', '测试分类1', 'ceshi1', '测试分类1', '测试分类1', '测试分类1', '85', '2018-08-29 21:19:31');
INSERT INTO `my_nav` VALUES ('86', '测试分类2', 'ceshi2', '测试分类2', '测试分类2', '测试分类2', '86', '2018-08-29 21:19:50');

-- ----------------------------
-- Table structure for my_online
-- ----------------------------
DROP TABLE IF EXISTS `my_online`;
CREATE TABLE `my_online` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '//id',
  `ip` varchar(100) DEFAULT NULL COMMENT '//IP',
  `lailu` text COMMENT '//来路URL',
  `browser` text COMMENT '//浏览器信息',
  `time` datetime DEFAULT NULL COMMENT '//时间',
  `dates` date DEFAULT NULL COMMENT '//时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13874 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of my_online
-- ----------------------------
INSERT INTO `my_online` VALUES ('13859', '127.0.0.1', 'http://localhost/myadmin/?a=admin', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:61.0) Gecko/20100101 Firefox/61.0', '2018-08-13 22:26:57', '2018-08-13');
INSERT INTO `my_online` VALUES ('13860', '127.0.0.1', '地址栏直接输入', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:61.0) Gecko/20100101 Firefox/61.0', '2018-08-14 21:25:03', '2018-08-14');
INSERT INTO `my_online` VALUES ('13861', '127.0.0.1', '地址栏直接输入', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:61.0) Gecko/20100101 Firefox/61.0', '2018-08-15 21:44:30', '2018-08-15');
INSERT INTO `my_online` VALUES ('13862', '127.0.0.1', '地址栏直接输入', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:61.0) Gecko/20100101 Firefox/61.0', '2018-08-16 21:28:29', '2018-08-16');
INSERT INTO `my_online` VALUES ('13863', '127.0.0.1', '地址栏直接输入', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:61.0) Gecko/20100101 Firefox/61.0', '2018-08-17 22:10:00', '2018-08-17');
INSERT INTO `my_online` VALUES ('13864', '::1', '地址栏直接输入', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36', '2018-08-17 22:39:56', '2018-08-17');
INSERT INTO `my_online` VALUES ('13865', '127.0.0.1', 'http://localhost/index.html', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:61.0) Gecko/20100101 Firefox/61.0', '2018-08-18 00:00:08', '2018-08-18');
INSERT INTO `my_online` VALUES ('13866', '127.0.0.1', '地址栏直接输入', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:61.0) Gecko/20100101 Firefox/61.0', '2018-08-19 09:40:35', '2018-08-19');
INSERT INTO `my_online` VALUES ('13867', '::1', 'http://localhost/myadmin/?a=admin', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36', '2018-08-24 22:02:18', '2018-08-24');
INSERT INTO `my_online` VALUES ('13868', '127.0.0.1', '地址栏直接输入', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:61.0) Gecko/20100101 Firefox/61.0', '2018-08-24 22:07:34', '2018-08-24');
INSERT INTO `my_online` VALUES ('13869', '127.0.0.1', '地址栏直接输入', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:61.0) Gecko/20100101 Firefox/61.0', '2018-08-25 22:24:45', '2018-08-25');
INSERT INTO `my_online` VALUES ('13870', '127.0.0.1', 'http://localhost/myadmin/?a=admin', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:61.0) Gecko/20100101 Firefox/61.0', '2018-08-26 00:01:25', '2018-08-26');
INSERT INTO `my_online` VALUES ('13871', '::1', '地址栏直接输入', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36', '2018-08-26 10:22:53', '2018-08-26');
INSERT INTO `my_online` VALUES ('13872', '127.0.0.1', '地址栏直接输入', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:61.0) Gecko/20100101 Firefox/61.0', '2018-08-28 21:00:03', '2018-08-28');
INSERT INTO `my_online` VALUES ('13873', '127.0.0.1', '地址栏直接输入', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:61.0) Gecko/20100101 Firefox/61.0', '2018-08-29 21:14:41', '2018-08-29');

-- ----------------------------
-- Table structure for my_system
-- ----------------------------
DROP TABLE IF EXISTS `my_system`;
CREATE TABLE `my_system` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '//ID',
  `title` varchar(200) DEFAULT NULL COMMENT '//网站标题',
  `url` varchar(200) DEFAULT NULL COMMENT '//网站域名',
  `thumb` varchar(200) NOT NULL COMMENT '//logo',
  `keywords` varchar(200) DEFAULT NULL COMMENT '//关键词',
  `description` varchar(300) DEFAULT NULL COMMENT '//网站描述',
  `webname` varchar(200) DEFAULT NULL COMMENT '网站名称',
  `page_size` varchar(20) NOT NULL COMMENT '//后台分页',
  `page_size_index` varchar(20) NOT NULL COMMENT '//前台分页',
  `footer` varchar(1000) DEFAULT NULL COMMENT '//底部信息',
  `index_main` text NOT NULL COMMENT '//首页内容',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of my_system
-- ----------------------------
INSERT INTO `my_system` VALUES ('1', 'PHPCMS建站系统', 'http://www.yccms.net', '../view/index/images/logo.png', 'cms,cms建站系统', 'YCCMS是一款PHP版CMS建站系统。程序页面设计简洁，生成静态html，后台功能强大。利于优化、超强收录、超强排名。适合做关键词排名、淘宝客程序，是个人、企业建站的理想选择。\r\n', 'YCCMS', '20', '20', 'Copyright ©2018 YCCMS.NET. All Rights Reserved', '<p>测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容<span style=\\\"color:#FF0000;\\\">测试内容测试内容</span>测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试。</p><p>内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容<strong>测试内容测试内容测试内</strong>容测试内容测试内容<span style=\\\"color:#3333FF;\\\"><strong>测试内容测试内容测</strong></span>试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容</p><p>内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容测试内容<br /></p>');
