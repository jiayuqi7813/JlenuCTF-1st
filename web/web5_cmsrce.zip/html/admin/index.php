<?php
require str_replace('\\','/',substr(dirname(__FILE__),0,-6)).'/config/run.inc.php';
?>