<?php
//require str_replace('\\','/',substr(dirname(__FILE__),0,-7)).'/config/run.inc.php';
define('ROOT_PATH',str_replace('\\','/',substr(dirname(__FILE__),0,-7))); 
require ROOT_PATH.'/config/config.inc.php';
require ROOT_PATH.'/public/smarty/Smarty.class.php';
//自动加载类
function __autoload($_className){
	if(substr($_className,-6)=='Action'){
		require ROOT_PATH.'/controller/'.ucfirst($_className).'.class.php';
	}elseif(substr($_className, -5) == 'Model'){
		require ROOT_PATH.'/model/'.ucfirst($_className).'.class.php';
	}else{
		require ROOT_PATH.'/public/class/'.ucfirst($_className).'.class.php';
	}
}
$_tpl=TPL::getInstance();
$_search=new SearchAction();
$_search->index();
?>