<?php
//图片控制器
class PicAction extends Action{
	public function __construct(){
		parent::__construct();
	}
	public function index(){
		$_dirPath=opendir(dirname(dirname(__FILE__)).'/uploads//');
		$_dirName='';
		$_picArr=array();
		while(!!$_dirName=readdir($_dirPath)){
			if($_dirName!='.' && $_dirName!='..'){
				$_picArr[] = $_dirName;
			}
		}
		krsort($_picArr);
		$this->_tpl->assign('picNum',count(scandir(dirname(dirname(__FILE__)).'/uploads//'))-2);
		$this->_tpl->assign('picArr',$_picArr);
		$this->_tpl->display('admin/public/picshow.tpl');
	}
	public function delall(){
		if(isset($_POST['send'])){
			if(validate::isNullString($_POST['pid'])) tool::layer_alert('没有选择任何图片!','?a=pic',7);
			$_fileDir=ROOT_PATH.'/uploads/';
			foreach($_POST['pid'] as $_value){
				$_filePath=$_fileDir.$_value;
				if(!unlink($_filePath)){
					tool::layer_alert('图片删除失败,请设权限为777!','?a=pic',7);
				}else{
					header('Location:?a=pic');
				}
			}
					
		}
		
	}
	

}



?>