<?php
//分类控制器
class NavAction extends Action{
	private $_art=null;
	public function __construct(){
		parent::__construct();
		$this->_art=new ArticleModel();
		$this->_model=new NavModel();
	}
	//分类列表
	public function index(){
		$_object=$this->_model->getAllNav();
		if($_object){
			foreach ($_object as $_value){		
				$this->_art->cid=$_value->id;
				$_value->arts=$this->_art->art_total();
			}
		}
		$this->_tpl->assign('AllNav',$_object);
		$this->_tpl->display('admin/nav/show.tpl');
	}
	
	//添加分类
	public function add(){
		if(isset($_POST['send'])){
			if(validate::isNullString($_POST['nav_name'])) Tool::t_back('ERROR:分类名称不能为空!!','?a=nav&m=add');
			$nav_ename=strtolower($_POST['nav_ename']);
			$this->_model->nav_name=$_POST['nav_name'];
			$this->_model->nav_ename=$nav_ename;
			$this->_model->keyword=$_POST['keyword'];
			$this->_model->title=$_POST['title'];
			$this->_model->info=$_POST['info'];
			if(tool::create_folder($nav_ename)){
				if($this->_model->add_nav()){
					tool::layer_alert('分类添加成功!','?a=nav&m=index',6);
				}else{
					tool::layer_alert('分类添加失败!','?a=nav&m=index',5);
				}
			}
		}
		
		if (isset($_GET['id'])) {
			$this->_model->id=$_GET['id'];
			$this->_tpl->assign('OneNav', $this->_model->findOne());
		}
		$this->_tpl->display('admin/nav/add.tpl');
	}
	
	//修改分类
	public function update(){
		if (isset($_GET['id'])) {
			$this->_model->id=$_GET['id'];
			$_findOne=$this->_model->findOne();
			$this->_model->nid=$_findOne[0]->nid;
			$_ParentNav=$this->_model->findParent();
			$this->_tpl->assign('OneNav',$_findOne );
			$this->_tpl->assign('ParentNav',$_ParentNav);
		}
		if(isset($_POST['send'])){
			$this->_model->id=$_POST['id'];
			$_findOne=$this->_model->findOne();
			$_old_nav_name=$_findOne[0]->nav_ename;
			$nav_ename=strtolower($_POST['nav_ename']);
			$this->_model->nav_name=$_POST['nav_name'];
			$this->_model->nav_ename=$nav_ename;
			$this->_model->title=$_POST['title'];
			$this->_model->keyword=$_POST['keyword'];
			$this->_model->info=$_POST['info'];
	
			if(tool::edit_folder($_old_nav_name,$nav_ename)){
				if($this->_model->update_nav()){
					tool::layer_alert('分类修改成功!','?a=nav&m=index',6);
				}else{
					tool::layer_alert('分类修改失败!','?a=nav&m=index',5);
				}
			}
				
		}
		$this->_tpl->display('admin/nav/update.tpl');
	}
	//删除分类
	public function delete(){
		//删除分类
		if(isset($_GET['id'])){
			$this->_art->cid=$_GET['id'];
			$this->_model->id=$_GET['id'];
			if($this->_art->get_artList()){
				tool::layer_alert('系统检测到该类下存在内容,暂时无法删除!!','?a=nav&m=index',7);
			}
		$_findOne=$this->_model->findOne();
			$dirname=$_findOne[0]->nav_ename;
			if(tool::delete_folder($dirname)){
				if($this->_model->delete_nav()){
					Tool::alertLocation(null, '?a=nav&m=index');
				}else{
					Tool::alertBack('删除失败!');
				}		
			}	
		}
		
	}
	//排序
	public function sort(){
		if(isset($_POST['send'])){
			$this->_model->sort=$_POST['sort'];
			$this->_model->setNavSort();
			tool::alertLocation(null,'?a=nav');
		}
	}
	//显示状态控制
	public function isshow(){
		$this->_model->id=$_GET['id'];
		$this->_model->isshow=$_GET['show'];
		$this->_model->setShow();
		tool::alertLocation(null,'?a=nav');
	}
	//清理目录下的所有静态文件
	public function clean(){
		if(isset($_GET['navname'])){
			$_navname=$_GET['navname'];
			$_dirPath=opendir(dirname(dirname(__FILE__)).'\\'.$_navname.'\\');
			$_fileDir=ROOT_PATH.'/'.$_navname.'/';
			$_cacheCount=count(scandir(dirname(dirname(__FILE__)).'\\'.$_navname.'\\')) - 2;
			$_dirName='';
			while(!!$_dirName=readdir($_dirPath)){
				if($_dirName!='.' && $_dirName!='..'){
					if(!unlink($_fileDir.$_dirName)){
						tool::layer_alert('ERROR:清理失败,请设权限为777!','?a=nav&m=index',7);
					}
				}
			}
			tool::layer_alert(''.$_cacheCount.' 个静态文件清理完毕!','?a=nav&m=index',1);
		}
	}

}



?>