<?php
//生成静态控制器
class HtmlAction extends Action{
	private $_nav;
	private $_art;
	private $_sys;
	private $_link;
	private $_dan;
	public function __construct(){
		parent::__construct();
		$this->_nav=new NavModel();
		$this->_art=new ArticleModel();
		$this->_sys=new SystemModel();
		$this->_link=new LinkModel();
	}
	//生成首页
	public function index(){
		if(isset($_POST['send'])){
		//公共
		$this->common();
		//友情链接
		$this->home_link();
		//首页主体
		$this->home_main();
		$content=$this->_tpl->fetch('index/public/index.tpl');
		$_filename=ROOT_PATH.'/index.html';
		Tool::makeHtmlFile($_filename, $content);
		//$this->_tpl->assign('num','<dd style="color:red;font-weight:bold;font-size:14px;">首页生成成功 !</dd>');
		tool::layer_alert('首页生成成功!','?a=html&index=1',6);
		}
		$this->_tpl->display('admin/public/createindex.tpl');
		
	}

	//生成一篇文章
	public function art(){
		//公共
		$this->common();
		$this->_art->id=$_GET['id'];
		$_art=$this->_art->get_artOne();
		//获得文章内容
		$this->art_content($_art);
		//得到父类目录名
		$this->_nav->id=$_art[0]->cid;
		$_parent=$this->_nav->findOne();
		//得到路径
		$_html=$_parent[0]->nav_ename.'/'.$_GET['id'].'.html';
		$content=$this->_tpl->fetch('index/public/article.tpl');
		$_filename=ROOT_PATH.'/'.$_html;
		Tool::makeHtmlFile($_filename, $content);
		//生成后更新生成状态
		$this->_art->update_html();
		tool::layer_alert('单个文章生成成功!',tool::getPrevPage(),1);
	}
	//生成所有文章
	public function arts(){
		if(isset($_GET['send'])){
		//echo str_repeat(' ',4096);
		//获取所有文章id
		$artAll=$this->_art->artAll();
		$htmls = array();
		//$i=0;
		//$progress = 0;
		if($artAll){
			//$pix = round(500 / count($artAll));
			foreach ($artAll as $_value){
				//公共
				$this->common();
				$this->_art->id=$_value->id;
				$_art=$this->_art->get_artOne();
				//获得文章内容
				$this->art_content($_art);
				//得到父类目录名
				$this->_nav->id=$_value->cid;
				$_parent=$this->_nav->findOne();
				//得到路径
				$_html=$_parent[0]->nav_ename.'/'.$_value->id.'.html';
				$content=$this->_tpl->fetch('index/public/article.tpl');
				$_filename=ROOT_PATH.'/'.$_html;
				Tool::makeHtmlFile($_filename, $content);
				//生成后更新生成状态
				$this->_art->update_html();
				//$i++;
				//$progress += $pix;
				//echo '<span style="font-size:12px;">正在生成 '.$_html.'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$i.'/'.count($artAll).'</span>';
				//echo '<div style="width:500px;margin-top:3px;height:20px;border:1px solid #CCC;"><div style="height:20px;background:#007CDE;width:'.$progress.'px;"><span style="color:red;padding-left:220px;">'.(($progress/500)*100).'%</span></div></div>';
				//ob_flush();
				//flush();
				//sleep(1);
				//echo '<script>document.body.innerHTML="";</script>';
				$htmls[] = $_html;
			}			
		}   
			Tool::deletetask('process');
			foreach ($htmls as $_value){
			Tool::addtask("process", array('html' => $_value));
			}
			$this->_tpl->assign('art',count($htmls));
			$this->_tpl->assign('processurl','?a=html&m=arts&process=1&step=1&all='.count($htmls).'');
			//$this->_tpl->assign('num','<dd style="color:red;font-weight:bold;font-size:14px;">内容生成完毕 ! 共 '.$i.' 条。</dd>');
			$this->_tpl->display('admin/public/arts_process.tpl');
			exit;
			 
		}
		if(!empty($_GET['process'])){
			$tasks=tool::gettask('process',100);//生成速度，越大越快
			$htmlss = $tasks['html'];
			$finishedpercent =Tool::gettaskpercent('process');
			exit(''.$finishedpercent."\t1\t".$htmlss);
		}
		
		$this->_tpl->display('admin/public/createhtml.tpl');
	}
	//生成列表
	public function lists(){
		if(isset($_POST['send'])){
			echo str_repeat(" ",1024);
			//公共
			$_sys=$this->_sys->system();
			$_syspage=$_sys[0]->page_size_index;
			$this->common();
			$_nav=$this->_nav->getAllNav();
			if($_nav){
				foreach ($_nav as $_value){
					//父类	
					$this->getNav($_value->id);//洋葱皮
					$_page=$this->getClassPage($_value->id,$_syspage);//ID,每页条数		
					for($i=1;$i<=$_page;$i++){
						if($i==1){		
							$_GET['page']=$i;
							$this->_tpl->assign('pages','');//页码
							$this->par_main($_value->id,$_value->nav_ename,$_syspage); //列表主体
							$_html=$_value->nav_ename.'/index.html';
							$content=$this->_tpl->fetch('index/public/list.tpl');
							$_filename=ROOT_PATH.'/'.$_html;
							Tool::makeHtmlFile($_filename, $content);
						}else{
							$_GET['page']=$i;
							$this->_tpl->assign('pages','_第'.$i.'页');//页码
							$this->par_main($_value->id,$_value->nav_ename,$_syspage); //列表主体
							$_html=$_value->nav_ename.'/index_'.$i.'.html';
							$content=$this->_tpl->fetch('index/public/list.tpl');
							$_filename=ROOT_PATH.'/'.$_html;
							Tool::makeHtmlFile($_filename, $content);
						}
						echo '<span style="font-size:12px;">正在生成 '.$_html.'</span><br />';
						ob_flush();
						flush();
						//sleep(2);
						echo '<script>document.body.innerHTML="";</script>';
					}
									
				}		
			}
			tool::layer_alert('列表生成完毕!','?a=html&m=lists&list=1',6);
			//$this->_tpl->assign('num','<dd style="color:red;font-weight:bold;font-size:14px;">列表生成完毕 !</dd>');			
		}
		$this->_tpl->display('admin/public/createlists.tpl');
	}
	//根据id查分页数
	private function getClassPage($_id,$_pagesize){
			$this->_art->cid=$_id;
			$_arts=$this->_art->top_total();
			if($_arts){
			$_arts=$this->_art->top_total();
				return ceil($_arts/$_pagesize);
			}else{
				return 1;
			}
	}
	//列表主体
	private function par_main($_id,$_ename,$_page){
		$this->_art->cid=$_id;
		parent::page2($this->_art->notop_total(),$_page,$this->_art,$_ename,$_fx='index');
		$_arts=$this->_art->no_top();
		if($_arts){
			foreach ($_arts as $_value){
				$_attr=explode(',', $_value->attr);
				if(in_array('加粗', $_attr)){
					$_value->b=1;
				}
			}
		}
		tool::objDate($_arts,'time');
		Tool::getFormString($_arts, 'title');
		$this->_tpl->assign('main',$_arts);
	}
	//获取一篇文章内容
	private function art_content($_art){
		if($_art){
			$this->_tpl->assign('title',StripSlashes($_art[0]->title));
			$this->_tpl->assign('time',$_art[0]->updatetime);
			$this->_tpl->assign('tag',StripSlashes($_art[0]->tag));
			$this->_tpl->assign('author',StripSlashes($_art[0]->author));
			$this->_tpl->assign('source',StripSlashes($_art[0]->source));
			$this->_tpl->assign('info',StripSlashes($_art[0]->info));
			$this->_tpl->assign('content',StripSlashes($_art[0]->content));
			$this->tag($_art[0]->tag);//tag
			$this->getNav($_art[0]->cid);//洋葱皮
			$this->next($_art[0]->id,$_art[0]->cid); //上一篇下一篇
			$this->xg($_art[0]->id,$_art[0]->cid);//相关内容
		}
	}
	//相关内容
	private function xg($_id,$_cid){
		//得到所属分类
		$this->_art->cid=$_cid;
	
		$this->_art->id=$_id;
		$_oneArt=$this->_art->get_artOne();
		$_tags = explode(',',$_oneArt[0]->tag);
			$this->_art->tag=$_tags[0];
			$art_xg=$this->_art->art_xg(5);
			Tool::getFormString($art_xg, 'title');
			Tool::objDate($art_xg, 'time');
			$this->_tpl->assign('xg',$art_xg);
	}
	//上一篇和下一篇(同一大分类下的)
	private function next($_id,$_cid){
		//得到父类
		$this->_art->id=$_id;
		$this->_art->cid=$_cid;
		//上一篇
		$_prev=$this->_art->art_prev();
		if($_prev){
			$prev_html='<a href="../'.$_prev[0]->html.'">'.StripSlashes($_prev[0]->title).'</a>';
		}else{
			$prev_html='无';
		}
		$this->_tpl->assign('prev',$prev_html);
		//下一篇
		$_next=$this->_art->art_next();
		if($_next){
			$next_html='<a href="../'.$_next[0]->html.'">'.StripSlashes($_next[0]->title).'</a>';
		}else{
			$next_html='无';
		}
		$this->_tpl->assign('next',$next_html);
		
	}
	//tag
	private function tag($_tag){
		$_attrS = explode(',',$_tag);
		if($_tag==''){
			$_html='无';
		}
		foreach ($_attrS as $_value) {
			$_html .= '<a href="../search/?s='.$_value.'">'.$_value.'</a>';
		}
		$this->_tpl->assign('tags',$_html);
	}
	//洋葱皮父类专用
	private function getNav($_id){
		$this->_nav->id=$_id;
		$_nav=$this->_nav->findOne();
		if($_nav){
			$_nav1 = '<a href="../'.$_nav[0]->nav_ename.'">'.$_nav[0]->nav_name.'</a>';
			$this->_tpl->assign('n',$_nav1);
			$this->_tpl->assign('ename',$_nav[0]->nav_ename);
			$this->_tpl->assign('nav_name',$_nav[0]->nav_name);
		}
		$this->_tpl->assign('classNav',$_nav[0]);
	}
	//首页主体
	private function home_main(){
		$_system=$this->_sys->system();
		$this->_tpl->assign('index_main',StripSlashes($_system[0]->index_main));	
	}
	
	//首页友情链接
	private function home_link(){
		$_link=$this->_link->get_link();
		$this->_tpl->assign('Link',$_link);
	}	
	//共用
	private function common(){
		//菜单
		$_nav=$this->_nav->getAllNav();
		$this->_tpl->assign('Nav',$_nav);
		
		//左侧列表
		$_list=$this->_art->sidebar_list(10);
		Tool::getFormString($_list, 'title');
		Tool::getFormString($_list, 't');
		Tool::subStr($_list,'title',15,'utf-8');
		$this->_tpl->assign('list',$_list);
		//共用部分
		$_sys=$this->_sys->system();
		$this->_tpl->assign('sys_thumb',StripSlashes($_sys[0]->thumb));
		$this->_tpl->assign('sys_footer',StripSlashes($_sys[0]->footer));
		$this->_tpl->assign('sys_title',StripSlashes($_sys[0]->title));
		$this->_tpl->assign('sys_keywords',StripSlashes($_sys[0]->keywords));
		$this->_tpl->assign('sys_desc',StripSlashes($_sys[0]->description));
		$this->_tpl->assign('webname',StripSlashes($_sys[0]->webname));
		$_webname=$_sys[0]->webname;
		if($_webname==''){
			$_fix='';
		}else{
			$_fix='_'.$_webname;
		}
		//标题后辍
		$this->_tpl->assign('t_fix',$_fix);
	}	
}


?>