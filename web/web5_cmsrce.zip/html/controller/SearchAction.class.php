<?php
//搜索控制器
class SearchAction extends Action{
	private $_nav;
	private $_art;
	private $_sys;
	public function __construct(){
		parent::__construct();
		$this->_nav=new NavModel();
		$this->_art=new ArticleModel();
		$this->_sys=new SystemModel();
	}	
	public function index(){
		//公共
		$this->common();
		$_keywords=htmlspecialchars($_GET['s']);
		$this->_art->inputkeyword=$_keywords;
		parent::page($this->_art->s_total(),10,$this->_art);
		@$_search=$this->_art->searchs();
		if($_search){
			foreach ($_search as $_value){
				$_value->title=str_replace($_keywords,'<span class="red">'.$_keywords.'</span>',$_value->title);
				$_value->info=str_replace($_keywords,'<span class="red">'.$_keywords.'</span>',$_value->info);
			}
		}
		tool::objDate($_search, 'time');
		Tool::subStr($_search,'info',150,'utf-8');
		$this->_tpl->assign('keyword',$_keywords);
		$this->_tpl->assign('sum',$this->_art->s_total());
		$this->_tpl->assign('search',$_search);
		$this->_tpl->display('index/public/search.tpl');
	}
	//共用
//共用
	private function common(){
		//菜单
		$_nav=$this->_nav->getAllNav();
		$this->_tpl->assign('Nav',$_nav);
		//左侧列表
		$_list=$this->_art->sidebar_list(10);
		Tool::getFormString($_list, 'title');
		Tool::getFormString($_list, 't');
		Tool::subStr($_list,'title',15,'utf-8');
		$this->_tpl->assign('list',$_list);
		//共用部分
		$_sys=$this->_sys->system();
		$this->_tpl->assign('sys_thumb',StripSlashes($_sys[0]->thumb));
		$this->_tpl->assign('sys_footer',StripSlashes($_sys[0]->footer));
		$this->_tpl->assign('sys_title',StripSlashes($_sys[0]->title));
		$this->_tpl->assign('sys_keywords',StripSlashes($_sys[0]->keywords));
		$this->_tpl->assign('sys_desc',StripSlashes($_sys[0]->description));
		$this->_tpl->assign('webname',StripSlashes($_sys[0]->webname));
		$_webname=$_sys[0]->webname;
		if($_webname==''){
			$_fix='';
		}else{
			$_fix='_'.$_webname;
		}
		//标题后辍
		$this->_tpl->assign('t_fix',$_fix);
	}	
}

?>