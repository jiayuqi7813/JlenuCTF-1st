<?php
//登录控制器
class LoginAction extends Action{
	public $_model=null;
	public function __construct(){
		parent::__construct();
		$this->_model=new AdminModel();
	}
	
	public function index(){
		if(isset($_POST['send'])){
			if(validate::isNullString($_POST['username'])) Tool::t_back('ERROR:用户名不能为空!','?a=login');
			if(validate::isNullString($_POST['password'])) Tool::t_back('ERROR:密码不能为空!','?a=login');
			if(!isset($_COOKIE['my_admin'])){
				if(!(validate::checkStrEquals(strtolower($_POST['code']), $_SESSION['code']))) Tool::t_back('ERROR:验证码错误!','?a=login');
			}
			$this->_model->username=$_POST['username'];
			$this->_model->password=sha1($_POST['password']);
			$_login=$this->_model->selectAdmin();
			if($_login){
				$_SESSION['admin']['username'] = $_login[0]->username;
				$_SESSION['admin']['count'] = $_login[0]->count;
				$_SESSION['admin']['time'] = $_login[0]->login_time;
				$this->_model->setLogin();
				if($_POST['checkbox']=='on'){
					setcookie('my_admin',$_POST['username'],time()+(7*24*60*60));
					setcookie('my_password',$_POST['password'],time()+(7*24*60*60));
				}else{
					setcookie('my_admin','');
					setcookie('my_password','');		
				}
				Tool::alertLocation(null, '?a=admin');
			}else{
				Tool::t_back('用户名或密码错误!','?a=login');
			}					
		}
		if (isset($_SESSION['admin'])) {
			Tool::alertLocation(null, '?a=admin');
		}
		$this->_tpl->assign('my_admin',isset($_COOKIE['my_admin']));
		$this->_tpl->display('admin/public/login.tpl');
	}
	//ajaxlogin
	public function ajaxLogin() {
		$this->_model->username=$_POST['user'];
		$this->_model->password=sha1($_POST['pass']);
		echo !$this->_model->check_Admin() ? 1 : 2;
	}
	//ajaxcode
	public function ajaxCode() {
		echo !(Validate::checkStrEquals(strtoupper($_SESSION['code']), strtoupper($_POST['code'])))? 1:2; //不相等输出空
	}
}


?>