<?php
//控制器基类
class Action {
	protected $_tpl = null;
	protected $_model = null;	
	protected function __construct() {
		$this->_tpl = TPL::getInstance();
		$this->_model = Factory::setModel();
		Tool::setRequest(); //表单转义和html过滤	
	}
	
	protected function page($_total,$_pagesize = PAGE_SIZE, $_model = null) {
		$this->_model = Validate::isNullString($_model) ? $this->_model : $_model;
		$_page = new Page($_total,$_pagesize);
		$this->_model->setLimit($_page->getLimit());
		$this->_tpl->assign('page',$_page->showpage());
		$this->_tpl->assign('num',($_page->getPage()-1)*$_pagesize);
	}
	//静态专用
	protected function page2($_total,$_pagesize = PAGE_SIZE, $_model = null,$_url2='',$_fx='') {
		$this->_model = $_model;
		$_page = new Page($_total,$_pagesize,$_url2,$_fx);
		$this->_model->setLimit($_page->getLimit());
		$this->_tpl->assign('page',$_page->listpage());
		$this->_tpl->assign('num',($_page->getPage()-1)*$_pagesize);
	}
	
	public function run() {
		$_m = isset($_GET['m']) ? $_GET['m'] : 'index';
		method_exists($this, $_m) ? eval('$this->'.$_m.'();') : $this->index();
	}
}
?>