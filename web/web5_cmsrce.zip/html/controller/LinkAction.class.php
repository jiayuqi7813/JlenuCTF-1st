<?php
//链接控制器
class LinkAction extends Action{
	public function __construct(){
		parent::__construct();
		$this->_model=new LinkModel();
	}
	//显示链接
	public function index(){
		parent::page($this->_model->_total(),10);
		$_object=$this->_model->get_link();
		$this->_tpl->assign('AllLink',$_object);
		$this->_tpl->display('admin/link/show.tpl');
	}
	//添加链接
	public function add(){
		if(isset($_POST['send'])){
			$this->getPost();
			if($this->_model->add_link()){
				tool::layer_alert('链接添加成功!','?a=link',6);
			}else{
				tool::layer_alert('链接添加失败!','?a=link',5);
			}
		}
		$this->_tpl->display('admin/link/add.tpl');
	}
	//修改链接
	public function update(){
		if(isset($_POST['send'])){
			$this->_model->id=$_POST['id'];
			$this->getPost();
			if($this->_model->update_link()){
				tool::layer_alert('链接修改成功!','?a=link',6);
			}else{
				tool::layer_alert('链接修改失败!','?a=link',5);
			}
		}
		if(isset($_GET['id'])){
			$this->_model->id=$_GET['id'];
			$_link=$this->_model->get_linkOne();
			if($_link){
				$this->_tpl->assign('id',StripSlashes($_link[0]->id));
				$this->_tpl->assign('linkname',StripSlashes($_link[0]->linkname));
				$this->_tpl->assign('linkurl',StripSlashes($_link[0]->linkurl));
				$this->_tpl->assign('prev_url',tool::getPrevPage());
			}
		}
		$this->_tpl->display('admin/link/update.tpl');
	}
	//删除链接
	public function delete(){
		if(isset($_GET['id'])){
			$this->_model->id=$_GET['id'];
			if($this->_model->delete_link()){
				Tool::alertLocation(null, tool::getPrevPage());
			}else{
				Tool::alertBack('删除链接失败!');
			}
		}
	}
	//post
	private function getPost(){
		if(validate::isNullString($_POST['linkname'])) Tool::t_back('ERROR:链接名称不能为空!',tool::getPrevPage());
		if(validate::isNullString($_POST['linkurl'])) Tool::t_back('ERROR:URL不能为空!!',tool::getPrevPage());
		$this->_model->linkname=$_POST['linkname'];
		$this->_model->linkurl=$_POST['linkurl'];	
	}
	//排序
	public function sort(){
		if(isset($_POST['send'])){
			$this->_model->sort=$_POST['sort'];
			$this->_model->setLinkSort();
			tool::alertLocation(null,'?a=link');
		}
	}

	

}



?>