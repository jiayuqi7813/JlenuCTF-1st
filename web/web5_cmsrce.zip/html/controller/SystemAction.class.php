<?php
//系统设置控制器
class SystemAction extends Action{
	public function __construct(){
		parent::__construct();
		$this->_model=new SystemModel();
	}

	//系统设置
	public function index(){
		if(isset($_POST['send'])){
			if(validate::isNullString($_POST['title'])) Tool::t_back('ERROR:网站标题为空!!','?a=system');
			if(validate::isNullString($_POST['url'])) Tool::t_back('ERROR:网站域名为空!!','?a=system');
			if(validate::isNullString($_POST['thumb'])) Tool::t_back('ERROR:logo为空!!','?a=system');
			if(validate::isNullString($_POST['keywords'])) Tool::t_back('ERROR:关键字为空!!','?a=system');
			if(validate::isNullString($_POST['description'])) Tool::t_back('ERROR:描述为空!!','?a=system');
			if(validate::isNullString($_POST['footer'])) Tool::t_back('ERROR:底部信息为空!!','?a=system');
			if(validate::isNullString($_POST['page_size'])) Tool::t_back('ERROR:后台分页条数为空!!','?a=system');
			if(validate::isNullString($_POST['page_size_index'])) Tool::t_back('ERROR:前台分页条数为空!!','?a=system');
			$this->_model->title=$_POST['title'];
			$this->_model->url=$_POST['url'];
			$this->_model->thumb=$_POST['thumb'];
			$this->_model->keywords=$_POST['keywords'];
			$this->_model->description=$_POST['description'];
			$this->_model->footer=$_POST['footer'];
			$this->_model->webname=$_POST['webname'];
			$this->_model->page_size=$_POST['page_size'];
			$this->_model->page_size_index=$_POST['page_size_index'];
			if($this->_model->setSystem()){
				//Tool::alertLocation('设置已保存!', '?a=system');
				tool::layer_alert('设置已保存!','?a=system',6);
			}else{
				//Tool::alertLocation('保存失败!', '?a=system');
				tool::layer_alert('保存失败!','?a=system',5);
			}
		}
		$_system=$this->_model->system();
		if($_system){
			$this->_tpl->assign('title',StripSlashes($_system[0]->title));
			$this->_tpl->assign('url',StripSlashes($_system[0]->url));
			$this->_tpl->assign('thumb',StripSlashes($_system[0]->thumb));
			$this->_tpl->assign('keywords',StripSlashes($_system[0]->keywords));
			$this->_tpl->assign('description',StripSlashes($_system[0]->description));
			$this->_tpl->assign('footer',StripSlashes($_system[0]->footer));
			$this->_tpl->assign('webname',StripSlashes($_system[0]->webname));
			$this->_tpl->assign('page_size',StripSlashes($_system[0]->page_size));
			$this->_tpl->assign('page_size_index',StripSlashes($_system[0]->page_size_index));
		}
		$this->_tpl->display('admin/public/system.tpl');
	}
	//首页内容
	public function main(){
		if(isset($_POST['send'])){
			$this->_model->index_main=$_POST['content'];
			if($this->_model->Upindex_main()){
				//Tool::alertLocation('设置已保存!', '?a=system');
				tool::layer_alert('首页内容已保存!','?a=system&m=main',6);
			}else{
				//Tool::alertLocation('保存失败!', '?a=system');
				tool::layer_alert('内容未更改或保存失败!','?a=system&m=main',5);
			}
		}
		$_system=$this->_model->system();
		if($_system){
			$this->_tpl->assign('content',StripSlashes($_system[0]->index_main));			
		}
		$this->_tpl->display('admin/public/index_main.tpl');
	}
	
	
}



?>