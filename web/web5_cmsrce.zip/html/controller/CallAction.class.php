<?php
//公共控制器
class CallAction extends Action{
	public function __construct(){
		parent::__construct();
	}
	
	
	//验证码
	public function validateCode() {
		$_vc = new ValidateCode();
		$_vc->doimg();
		$_SESSION['code'] = $_vc->getCode();
	}
	//上传产品图片upfile
	public function upFile() {
		$this->_tpl->display('admin/public/upfile.tpl');
	}
	//处理上传图片
	public function upLoad() {
		if (isset($_POST['send'])) {
			$_logoupload = new LogoUpload('pic',$_POST['MAX_FILE_SIZE']);
			$_path = $_logoupload->getPath();
			$_img = new Image($_path);
			$_img->xhImg(960,0);
			$_img->out();
			//echo $_path;
			$_logoupload->alertOpenerClose('图片上传成功！','..'.$_path);
		} else {
			exit('警告：文件过大或者其他未知错误导致浏览器崩溃！');
		}
	}
	//xheditor编辑器专用上传
	public function xhUp() {
		if (isset($_GET['type'])) {
			$_fileupload = new FileUpload('filedata',10);
			$_err=$_fileupload->checkError();
			$_path = $_fileupload->getPath();
			$_msg="'..$_path'";
			$_img = new Image($_path);
			$_img->xhImg(650,0);
			$_img->out();
			echo "{'err':'".$_err."','msg':".$_msg."}";
			exit();
		} else {
		Tool::alertBack('警告：由于非法操作导致上传失败！');
		}
	}
}



?>