<?php
class zip {

    //压缩文件   要压缩的文件路径数组   保存压缩文件的路径
    public static function toZip(array $fileArr,$savepath) {
        $zip = new ZipArchive();
        if($zip->open($savepath,ZipArchive::OVERWRITE) === true){ //创建一个空的zip文件
            foreach($fileArr as $v){
                $filename = pathinfo($v);
                $zip->addFile($v,$filename['basename']);
            }
            $zip->close();
        }else{
            Tool::alertBack('压缩文件失败，请查看【'.$savepath.'】是否有写的权限');
        }
    }
    //压缩整个网站
    public static function siteToZip($path,$base_path){
    	$zip = new ZipArchive();
    	if($zip->open($base_path,ZipArchive::OVERWRITE) === true){ //创建一个空的zip文件
    		self::addFileToZip($path, $zip,$base_path);
    		$zip->close();
    	}
    }
    //添加多个文件
    private static function addFileToZip($path, $zip,$base_path) {
    	$handler = opendir($path);
    	while (($filename = readdir($handler)) !== false) {
    		if ($filename != "." && $filename != "..") {   
    			if (is_dir($path . "/" . $filename)) { 				
    				$zip->addEmptyDir($path . "/" . $filename);
    				self::addFileToZip($path . "/" . $filename, $zip,$base_path);
    			} else {
    				$zip->addFile($path . "/" . $filename);
    			}
    		}
    	}
    	@closedir($path);
    }
    //要解压的文件路径    解压到哪的路径 不填为压缩文件所在路径，也就是解压到当前路径
    public static function openZip($zippath,$dir=false){
        $zip = new ZipArchive();
        if($zip->open($zippath) === true){
            if(!$dir) $dir = dirname($zippath);
            $zip->extractTo($dir);
            $zip->close();//关闭处理的zip文件
        }else{
            Tool::alertBack('解压文件失败，请查看【'.dirname($zippath).'】是否有读的权限');
        }
    }
    
    //根据压缩文件返回里面的文件数量
    public static function fileNum($zippath){
        $zip = new ZipArchive();
        $zip->open($zippath);
        $num = $zip->numFiles;
        $zip->close();//关闭处理的zip文件
        return $num;
    }
    
}


?>
