document.write('<style type="text/css">');
document.write('td {padding:0}');
document.write('.color_div_o {width:16px;height:16px;padding:4px 0 0 4px;background:#B6BDD2;cursor:crosshair;}');
document.write('.color_div_t {width:16px;height:16px;padding:4px 0 0 4px;background:#F1F2F3;}');
document.write('.color_div {border:#808080 1px solid;width:10px;height:10px;line-height:10px;font-size:1px;}');
document.write('</style>');
var color_id = 1; var color_bk = color_htm = '';
color_htm += '<table cellpadding="0" cellspacing="0" bgcolor="#427FB8" width="160"><tr>';
color_htm += '<td><input type="text" style="font-size:12px;width:60px;height:15px;line-height:15px;border:#427FB8 1px solid;margin:3px 5px;" value="" id="color_viewview" onblur="color_select(this.value);" onkeyup="color_view(this.value);" ondblclick="this.value=\'\';"/></td>';
color_htm += '<td align="right" style="color:#FFFFFF;font-weight:bold;cursor:pointer;" onclick="color_close();" title="Close">&#215;</td>';
color_htm += '</tr></table>';
color_htm += '<div id="my_color_show"></div>';
var isIE = (document.all && window.ActiveXObject && !window.opera) ? true : false;
function $_(i) {return document.getElementById(i);}
function _N(i) {$_(i).style.display = 'none';}
function _H(t) {
	var t = t ? t : 'select';
	if(isIE) {
		var arVersion = navigator.appVersion.split("MSIE"); var IEversion = parseFloat(arVersion[1]);		
		if(IEversion >= 7 || IEversion < 5) return;
		var ss = document.body.getElementsByTagName(t);					
		for(var i=0;i<ss.length;i++) {ss[i].style.visibility = 'hidden';}
	}
}
function _V(t) {
	var t = t ? t : 'select';
	if(isIE) {
		var arVersion = navigator.appVersion.split("MSIE"); var IEversion = parseFloat(arVersion[1]);		
		if(IEversion >= 7 || IEversion < 5) return;
		var ss = document.body.getElementsByTagName(t);					
		for(var i=0;i<ss.length;i++) {ss[i].style.visibility = 'visible';}
	}
}
function color_show(id, color, obj) {
	_H();
	if($_('my_color') == null) {
		var my_color_div = document.createElement("div");
		with(my_color_div.style) {zIndex = 9999; position = 'absolute'; display = 'none'; width = '160px'; padding = '1px'; top = 0; left = 0; border = '#CCCCCC 1px solid'; backgroundColor = '#FFFFFF';}
		my_color_div.id = 'my_color';
		document.body.appendChild(my_color_div);
	}
	var aTag = obj; var leftpos = toppos = 0;
	do {aTag = aTag.offsetParent; leftpos	+= aTag.offsetLeft; toppos += aTag.offsetTop;
	} while(aTag.offsetParent != null);
	$_('my_color').style.left = (obj.offsetLeft + leftpos) + 'px';
	$_('my_color').style.top = (obj.offsetTop + toppos + 20) + 'px';
	$_('my_color').innerHTML = color_htm;
	color_id = id;
	color_bk = color;
	$_('my_color').style.display = '';
	if(color) color_view(color);
	color_setup(color);
}
function color_hide() {_N('my_color'); _V();}
function color_close() {color_hide(); $_('color_img_'+color_id).style.backgroundColor = color_bk;}
function color_select(color) {$_('color_input_'+color_id).value = color; $_('color_img_'+color_id).style.backgroundColor = color; color_hide();}
function color_setup(color) {
	var colors = [
	'#000000', '#993300', '#333300', '#003300', '#003366', '#000080', '#333399', '#333333',
	'#800000', '#FF6600', '#808000', '#008000', '#008080', '#0000FF', '#000000', '#808080', 
	'#FF0000', '#FF9900', '#99CC00', '#339966', '#33CCCC', '#3366FF', '#800080', '#999999', 
	'#FF00FF', '#FFCC00', '#FFFF00', '#00FF00', '#00FFFF', '#00CCFF', '#993366', '#C0C0C0', 
	'#FF99CC', '#FFCC99', '#FFFF99', '#CCFFCC', '#CCFFFF', '#99CCFF', '#CC99FF', ''];
	var colors_select = '';
	colors_select += '<table cellpadding="0" cellspacing="0">'
	for(i = 0; i < colors.length; i++) {
		if(i%8 == 0) colors_select += '<tr>';
		colors_select += '<td width="20" height="20">';
		if(color == colors[i]) {
			colors_select += '<div class="color_div_o" onmouseover="color_view(\''+colors[i]+'\');" onclick="color_select(\''+colors[i]+'\');">';
		} else {
			colors_select += '<div class="color_div_t" onmouseover="this.className=\'color_div_o\';color_view(\''+colors[i]+'\');" onmouseout="this.className=\'color_div_t\';" onclick="color_select(\''+colors[i]+'\');">';
		}
		colors_select += '<div class="color_div" style="background:'+colors[i]+'">&nbsp;</div></div></td>';
		if(i%8 == 7) colors_select += '</tr>';
	}
	colors_select += '</table>';
	$_('my_color_show').innerHTML = colors_select;
}
function color_view(color) {try {$_('color_viewview').value = color; $_('color_viewview').style.color = color; $_('color_img_'+color_id).style.backgroundColor = color;} catch(e) {}}