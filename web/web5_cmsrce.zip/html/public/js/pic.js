$(function(){
	$('dl#allcheckbox dd').click(function(){
		var checkeds = !$(this).find('input:checkbox').attr('checked');
		$(this).find('input:checkbox').attr('checked',checkeds);
	});
});
//选择全部
function CheckAll(form) {
	  for (var i = 0 ;i<form.elements.length; i++) {
	   var e = form.elements[i] ;  
	   if (e.name!='chkall') {   
	    e.checked = form.chkall.checked; 
	   }
	  }
} 