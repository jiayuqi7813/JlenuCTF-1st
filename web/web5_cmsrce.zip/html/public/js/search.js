window.onload = function(){
	var search=document.getElementById("search1");
	search.onblur=function(){
		if(search.value==''){
			search.value='请输入搜索内容';
			} 
		search.style.color='#000';
	}
	search.onclick=function(){
		if(search.value=='请输入搜索内容'){
			search.value='';
			}
		search.style.color='#000';
	}

};