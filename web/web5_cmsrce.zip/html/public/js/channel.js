//左侧菜单选中
$(function(){
	$('.menu_a').click(function(){
		$('.menu_a').removeClass("on");
		$(this).addClass("on");
	});
})

//导航切换
function channel(j) {
	//获取所有的dl标签
	var dl = document.getElementsByTagName('dl');
	//把所有的dl标签隐藏起来
	for (var i = 0; i < dl.length; i ++) {
		dl[i].style.display = 'none';
	}
	//把点击的那个显示出来
	dl[j].style.display = 'block';
}

//导航背景
function admin_top_nav(j) {
	for (i=1;i<5;i++) {
		document.getElementById('nav'+i).style.backgroundPosition = 'left top';
		document.getElementById('nav'+i).style.color = '#fff';
	}
	document.getElementById('nav'+j).style.backgroundPosition = 'left bottom';
	document.getElementById('nav'+j).style.color = '#3b6ea5';
}