$(function(){
	$('#add').validate({
		   highlight:function(element,errorClass){
		   $(element).css('border','1px solid red');   
		   $(element).parent().find('span').html(' ').removeClass('succ'); 
		   },
		   unhighlight:function(element,errorClass){
		   $(element).css('border','1px solid #ccc');
		   $(element).parent().find('span').html(' ').addClass('succ');  
		   },
		   rules:{
			   	nav_name:{
					required:true
				},
				nav_ename:{
					required:true
				},
				title:{
					required:true
				},
				keyword:{
					required:true
				},
				info:{
					required:true
				}
			},
		 messages:{
			 	nav_name:{
					required:'请填写分类名称!'
				},
				nav_ename:{
					required:'请填写英文别名!'
				},
				title:{
					required:'请填写分类标题!'
				},
				keyword:{
					required:'请填写关键词!'
				},
				info:{
					required:'请填写描述!'
				}
			}
		});		
});

  
