$(function(){
	//编缉器配置xheditor
	$('#content').xheditor({
		upImgUrl:"?a=call&m=xhUp&type=xh",
		upImgExt:"jpg,jpeg,gif,png",
		html5Upload:false,
		tools:'Cut,Copy,Paste,Pastetext,|,Blocktag,Fontface,FontSize,Bold,Italic,Underline,Strikethrough,FontColor,BackColor,SelectAll,Removeformat,|,Align,List,Outdent,Indent,|,Link,Unlink,Anchor,Img,Hr,Emot,Table,|,Source,Preview,Fullscreen,Print,About'	
	});	
});

